#!/usr/bin/python3
# -*- encoding: utf-8 -*-
'''
@File Name    : myos.py
@Time         : 2024/02/14 13:53:20
@Author       : L WANG
@Contact      : wang@i-dna.org
@Version      : 0.0.0
@Description  : This file contains the system level file manipulation functions
'''

import re
import os
import os.path as osp

def check_path(path):
    if not osp.exists(path):
        print("The given path does not exist! Creat a new one")
        os.makedirs(path)
        return path
    else:
        return path


def is_Exist(file_path):
    if not osp.exists(file_path):
        raise FileExistsError(f"Error! The file path {file_path} is not valid")
    else:
        return file_path

def auto_save_file(path):
    directory, file_name = os.path.split(path)
    while os.path.isfile(path):
        pattern = '(\d+)\)\.'
        if re.search(pattern, file_name) is None:
            file_name = file_name.replace('.', '(0).')
        else:
            current_number = int(re.findall(pattern, file_name)[-1])
            new_number = current_number + 1
            file_name = file_name.replace(f'({current_number}).', f'({new_number}).')
        path = os.path.join(directory + os.sep + file_name)
    return path

def format_number(num):
    return "{:03d}".format(num)

